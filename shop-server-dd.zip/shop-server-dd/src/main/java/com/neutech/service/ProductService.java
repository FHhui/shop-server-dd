package com.neutech.service;

import com.neutech.entity.Category;
import com.neutech.form.ProductForm;
import com.neutech.vo.ResultVO;
import org.springframework.web.bind.annotation.RequestParam;

public interface ProductService {

    ResultVO listProduct(Integer pageNum, Integer pageSize);

    ResultVO getProductByCategory(Integer categoryId);

    ResultVO addProduct(ProductForm productForm);

    ResultVO updateProduct(ProductForm productForm);

    ResultVO deleteProduct(Integer ids);

    ResultVO getProductById(Integer id);

    ResultVO getProductByName(String name, Integer type);

    ResultVO engineCarousel();
}
