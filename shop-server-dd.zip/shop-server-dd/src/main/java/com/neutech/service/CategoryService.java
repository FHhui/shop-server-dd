package com.neutech.service;

import com.neutech.vo.ResultVO;

public interface CategoryService {

    ResultVO listTopStruct();

}
