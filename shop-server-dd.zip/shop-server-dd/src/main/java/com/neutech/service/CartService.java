package com.neutech.service;

import com.neutech.entity.Cart;
import com.neutech.entity.Product;
import com.neutech.form.CartForm;
import com.neutech.vo.ResultVO;
import org.springframework.stereotype.Service;

@Service
public interface CartService {
    //购物车的增删改查
    //以分页的形式获得购物车的全部内容
    ResultVO listCarts(Integer userID);
    //向购物车中添加新的物品;
    ResultVO addProductToCarts(CartForm cartForm);
    //删除购物车中的某项物品
    ResultVO DeleteCarts(Integer userId,Integer goodId);
    //更新购物车的状态
    ResultVO upDateCarts(CartForm cartForm);
    //购物车结算
    //在结算的过程当中，需要先对购物车状态进行更新，更新完成后，再调用结算。
    ResultVO EvaluateCarts(Integer userId);
    //更新购物车选中状态
    ResultVO changeCheck(Integer userId,Integer id,Integer check);
    //更新购物车中商品的数量
    ResultVO changeCount(Integer userId,Integer id,Integer quantity);
    //通过购物车，返回订单
    ResultVO submitOrderByCart(Integer userId,Integer shippingId,Integer payType);
}
