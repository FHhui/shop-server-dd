package com.neutech.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.neutech.entity.*;
import com.neutech.enumeration.ResultExceptionEnum;
import com.neutech.form.CartForm;
import com.neutech.mapper.*;
import com.neutech.service.CartService;
import com.neutech.vo.CartVO;
import com.neutech.vo.ProductVO;
import com.neutech.vo.ResultVO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class CartServiceImpl implements CartService {
    @Autowired
    private CartMapper cartMapper;

    @Autowired
    private ProductMapper productMapper;

    @Autowired
    private OrderMapper orderMapper;

    @Autowired
    private OrderitemMapper orderitemMapper;

    @Autowired
    private com.neutech.mapper.payInfoMapper payInfoMapper;
    /**
     * @description:根据用户ID，获取他的购物车中的所有的商品
     */
    @Override
    public ResultVO listCarts(Integer userId) {
        List<Cart> cartList = cartMapper.listCart(userId);
        List<CartVO> cartVOList = new ArrayList<>();
        for (Cart cart : cartList) {
            ProductVO productVO=new ProductVO(productMapper.getOneById(cart.getId()));
            CartVO cartVO = new CartVO(cart,productVO);
           // BeanUtils.copyProperties(cart, cartVO);
            cartVOList.add(cartVO);
        }
//        pageInfo.setList(cartVOList);
        return ResultVO.success(cartVOList);
    }

    /**
     * @description:向购物车中添加新的
     */
    @Override
    public ResultVO addProductToCarts(CartForm cartForm) {
        if (cartMapper.getOneByID(cartForm.getId()) != null) {
            return ResultVO.error(ResultExceptionEnum.DATA_NON_EXISTS.getCode(), "类别不存在");
        }
        Cart cart = new Cart();
        BeanUtils.copyProperties(cartForm, cart);
        Date date = new Date();
        cart.setCreateTime(date);
        cart.setUpdateTime(date);
        int row = cartMapper.add(cart);
        return row > 0 ? ResultVO.success() : ResultVO.error(0, "数据保存失败");
    }

    /**
     * @description:根据单位购物车ID，获取购物车中的某一个单位
     */
    @Override
    public ResultVO DeleteCarts(Integer userId,Integer goodId) {
        int row = cartMapper.deleteById(userId,goodId);
        return row > 0 ? ResultVO.success() : ResultVO.error(0, "数据删除失败");
    }

    /**
     * @description:根据购物车的输入，更新购物车中的商品的状态
     */
    @Override
    public ResultVO upDateCarts(CartForm cartForm) {
        Cart cart = new Cart();
        BeanUtils.copyProperties(cartForm, cart);
        cart.setUpdateTime(new Date());
        int row = cartMapper.update(cart);
        return row > 0 ? ResultVO.success() : ResultVO.error(0, "更新失败");
    }
    /**
     * @description:根据购物车中购物单元的checked属性，得到购物车总结
     *
     */
    @Override
    public ResultVO EvaluateCarts(Integer userId) {
        List<Cart> cartList = cartMapper.listCart(userId);
        BigDecimal all_price=new BigDecimal(0);
        for (Cart cart : cartList) {
            if (cart.getChecked()==1){
                Product product=productMapper.getOneById(cart.getProductId());
                all_price=all_price.
                        add(product.getPrice().multiply(BigDecimal.valueOf(cart.getQuantity())));
                /**allprice+=productprice*quantity
                * **/
            }
        }
        return ResultVO.success(all_price);
    }

    @Override
    public ResultVO changeCheck(Integer userId, Integer id, Integer check) {
        int row = cartMapper.changeCheck(userId, id, check);
        return row > 0 ? ResultVO.success() : ResultVO.error(0, "更新失败");
    }

    @Override
    public ResultVO changeCount(Integer userId, Integer id, Integer quantity) {
        int row = cartMapper.changeCount(userId, id, quantity);
        return row > 0 ? ResultVO.success() : ResultVO.error(0, "更新失败");
    }

    @Override
    public ResultVO submitOrderByCart(Integer userId, Integer shippingId, Integer payType) {
//        List<Cart> cartList = cartMapper.listCart(userId);
//        BigDecimal all_price=new BigDecimal(0);
//        for (Cart cart : cartList) {
//            if (cart.getChecked()==1){
//                Product product=productMapper.getOneById(cart.getProductId());
//                all_price=all_price.
//                        add(product.getPrice().multiply(BigDecimal.valueOf(cart.getQuantity())));
//                /**allprice+=productprice*quantity
//                 * **/
//            }
//        }
//        Order order=new Order();
//        order.setUser_id(userId);
//        order.setShipping_id(shippingId);
//        order.setPayment(all_price.doubleValue());
//        order.setPayment_type(payType);
//        Date date=new Date();
//        order.setCreate_time(date);
//        int cow1=orderMapper.add(order);
//        for (Cart cart:cartList){
//            Product product=productMapper.getOneById(cart.getProductId());
//            Orderitem orderitem=new Orderitem();
//            orderitem.setUser_id(userId);
//            orderitem.setOrder_no(order.getId());
//            orderitem.setProduct_id(product.getId());
//            orderitem.setProduct_name(product.getName());
//            orderitem.setProduct_image(product.getMainImage());
//            orderitem.setCurrent_unit_price(product.getPrice());
//            orderitem.setQuantity(cart.getQuantity());
//            orderitem.setTotal_price(product.getPrice().multiply((BigDecimal.valueOf(cart.getQuantity()))));
//            orderitem.setCreate_time(date);
//            int cow2=orderitemMapper.add(orderitem);
//            if (cow2<0)    return ResultVO.error(-1,"操作失败");
//        }
//        payInfo payinfo=new payinfo();
//        payinfo.setUser_id(userId);
//        payinfo.setOrder_no(order.getId());
//        payinfo.setPay_platform(payType);
//        payinfo.setCreate_time(date);
//        int cow3=payInfoMapper.add(payinfo);
//        if(cow1<0 ||cow3<0){
//            return ResultVO.error(-1,"操作失败");
//        }
        return ResultVO.success();
    }
}
