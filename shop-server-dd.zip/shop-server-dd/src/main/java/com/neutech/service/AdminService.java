package com.neutech.service;
import com.neutech.form.AdminForm;
import com.neutech.vo.ResultVO;

public interface AdminService {
    ResultVO GetAllUsers();

    ResultVO RemoveUserById(Integer id);

    ResultVO addNewUser(AdminForm adminForm);

    ResultVO modifyUserById(AdminForm adminForm);

    ResultVO getUserInfo(Integer id);

    ResultVO login(String email,String pwd);

    ResultVO regist(String email,String pwd);

    ResultVO modifyPwd(String email,String pwd);

    ResultVO modifyUserUsername(Integer id,String username);

    ResultVO modifyUserPhone(Integer id,String phone);
}
