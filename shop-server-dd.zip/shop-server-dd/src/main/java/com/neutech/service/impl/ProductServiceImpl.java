package com.neutech.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.neutech.entity.Category;
import com.neutech.entity.Product;
import com.neutech.enumeration.ProductStatusEnum;
import com.neutech.enumeration.ResultExceptionEnum;
import com.neutech.form.ProductForm;
import com.neutech.mapper.CategoryMapper;
import com.neutech.mapper.ProductMapper;
import com.neutech.service.ProductService;
import com.neutech.vo.ProductVO;
import com.neutech.vo.ResultVO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductMapper productMapper;

    @Autowired
    private CategoryMapper categoryMapper;

    @Override
    public ResultVO listProduct(Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<Product> productList = productMapper.listProduct();
        PageInfo pageInfo = PageInfo.of(productList);
        List<ProductVO> productVOList = new ArrayList<>();
        for (Product product : productList) {
            ProductVO productVO = new ProductVO(product);
            // 对象拷贝, 拷贝原则是属性名和类型相同
            // 单独处理status问题
            //productVO.setStatus(ProductStatusEnum.getProductStatusEnum(product.getStatus()));
            productVOList.add(productVO);
        }
        // pageHelper的问题,PageInfo.of方法必须放入原始数据,不能是转化后,否则分页参数不对
        pageInfo.setList(productVOList);
        return ResultVO.success(pageInfo);
    }

    @Override
    public ResultVO getProductByCategory(Integer categoryId) {
//        PageHelper.startPage(pageNum, pageSize);
        List<Product> productList = productMapper.getProductByCategory(categoryId);
//        PageInfo pageInfo = PageInfo.of(productList);
        List<ProductVO> productVOList = new ArrayList<>();
        for (Product product : productList) {
            ProductVO productVO = new ProductVO(product);
            // 对象拷贝, 拷贝原则是属性名和类型相同
//            BeanUtils.copyProperties(product, productVO);
            // 单独处理status问题
//            productVO.setStatus(ProductStatusEnum.getProductStatusEnum(product.getStatus()));
            productVOList.add(productVO);
        }
        // pageHelper的问题,PageInfo.of方法必须放入原始数据,不能是转化后,否则分页参数不对
//        pageInfo.setList(productVOList);
        return ResultVO.success(productVOList);
    }

    @Override
    public ResultVO addProduct(ProductForm productForm) {
        // 数据校验
        // 状态校验
        if (ProductStatusEnum.getProductStatusEnum(productForm.getStatus()) == null) {
            return ResultVO.error(ResultExceptionEnum.DATA_NON_EXISTS.getCode(), "状态值不合法");
        }
        // 校验类别id是否存在
        if (categoryMapper.getOneById(productForm.getCategory_id()) == null) {
            return ResultVO.error(ResultExceptionEnum.DATA_NON_EXISTS.getCode(), "类别不存在");
        }

        // 准备数据
        Product product = new Product(productForm);

        // 处理两个时间


        int row = productMapper.save(product);

        return row > 0 ? ResultVO.success() : ResultVO.error(1004, "未知错误,数据插入失败");
    }

    @Override
    public ResultVO updateProduct(ProductForm productForm) {
        // 类别校验
        if (productForm.getCategory_id() != null &&
                categoryMapper.getOneById(productForm.getCategory_id()) == null) {
            return ResultVO.error(ResultExceptionEnum.DATA_NON_EXISTS.getCode(), "类别不存在");
        }
        if (productForm.getStatus() != null &&
                ProductStatusEnum.getProductStatusEnum(productForm.getStatus()) == null) {
            return ResultVO.error(ResultExceptionEnum.DATA_NON_EXISTS.getCode(), "状态值不合法");
        }
        // 转化数据类型
        Product product = new Product(productForm);

        product.setUpdateTime(new Date());

        int row = productMapper.update(product);

        return row > 0 ? ResultVO.success() : ResultVO.error(1004, "未知错误,数据更新失败");
    }

    @Override
    public ResultVO deleteProduct(Integer ids) {
        int row = productMapper.deleteAllByIds(ids);
        return row > 0 ? ResultVO.success() : ResultVO.error(1004, "未知错误,数据更新失败");
    }

    @Override
    public ResultVO getProductById(Integer id) {
        Product product = productMapper.getOneById(id);
        if (product == null) {
            return ResultVO.error(1005, "商品不存在");
        }
        return ResultVO.success(product);
    }

    @Override
    public ResultVO getProductByName(String name, Integer type) {
//        PageHelper.startPage(pageNum, pageSize);
        List<Product> productList = productMapper.getProductByName(name,type);
//        PageInfo pageInfo = PageInfo.of(productList);
        List<ProductVO> productVOList = new ArrayList<>();
        for (Product product : productList) {
            //都是基本数据类型，直接进行浅拷贝赋值就可以
            ProductVO productVO = new ProductVO(product);
            // 对象拷贝, 拷贝原则是属性名和类型相同
//            BeanUtils.copyProperties(product, productVO);
            // 单独处理status问题
            // productVO.setStatus(ProductStatusEnum.getProductStatusEnum(product.getStatus()));
            productVOList.add(productVO);
        }
        // pageHelper的问题,PageInfo.of方法必须放入原始数据,不能是转化后,否则分页参数不对
//        pageInfo.setList(productVOList);
        return ResultVO.success(productVOList);
    }

    /**
     * @description:加载首页轮播图
     * */
    @Override
    public ResultVO engineCarousel() {
        List<Product> productList = productMapper.listProduct();
        List<HashMap<String,String>> datas=new ArrayList<>();
        int i=0;
        for (Product product : productList) {
            //ProductVO productVO = new ProductVO();
            // 对象拷贝, 拷贝原则是属性名和类型相同
            //BeanUtils.copyProperties(product, productVO);
            // 单独处理status问题
            //productVO.setStatus(ProductStatusEnum.getProductStatusEnum(product.getStatus()));
            //productVOList.add(productVO);
            HashMap<String,String> data=new HashMap<>();
            data.put("id",String.valueOf(product.getId()));
            data.put("main_image",product.getMainImage());
            datas.add(data);
            if (i<5){ i++;}else{break;}
        }


        // pageHelper的问题,PageInfo.of方法必须放入原始数据,不能是转化后,否则分页参数不对
        //pageInfo.setList(productVOList);

        return ResultVO.success(datas);

    }


}
