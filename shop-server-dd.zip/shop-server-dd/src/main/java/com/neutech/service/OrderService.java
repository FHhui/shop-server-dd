package com.neutech.service;

import com.neutech.vo.ResultVO;

public interface OrderService {

    ResultVO getOrder(Integer orderid);
    ResultVO loadOrders(Integer userid,String type);
}
