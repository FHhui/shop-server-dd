package com.neutech.service.impl;

import com.neutech.entity.Admin;
import com.neutech.enumeration.AdminStatusEnum;
import com.neutech.enumeration.ResultExceptionEnum;
import com.neutech.form.AdminForm;
import com.neutech.mapper.AdminMapper;
import com.neutech.service.AdminService;
import com.neutech.vo.AdminVO;
import com.neutech.vo.ResultVO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    private AdminMapper adminMapper;


    @Override
    public ResultVO GetAllUsers() {
        List<Admin> adminList = adminMapper.GetAllUser();
        List<AdminVO> adminVOList = new ArrayList<>();
        for (Admin admin : adminList) {
            AdminVO adminVO = new AdminVO();
            // 对象拷贝, 拷贝原则是属性名和类型相同
            BeanUtils.copyProperties(admin, adminVO);
            // 单独处理status问题
            adminVO.setUserid(admin.getId());
            adminVOList.add(adminVO);
        }
        return ResultVO.success(adminVOList);
    }

    @Override
    public ResultVO RemoveUserById(Integer id) {
        int row = adminMapper.RemoveUser(id);
        return row > 0 ? ResultVO.success() : ResultVO.error(-2, "删除管理员失败");
    }

    @Override
    public ResultVO addNewUser(AdminForm adminForm) {
        if(AdminStatusEnum.getAdminStatusEnum(adminForm.getRole())==null){
            return ResultVO.error(ResultExceptionEnum.DATA_NON_EXISTS.getCode(), "状态值不合法");
        }
        Admin admin = new Admin();
        BeanUtils.copyProperties(adminForm,admin);
        Date date = new Date();
        admin.setCreate_time(date);
        admin.setUpdate_time(date);
        int row = adminMapper.addUser(admin);

        return row > 0 ? ResultVO.success() : ResultVO.error(-2, "添加管理员失败");
    }

    @Override
    public ResultVO modifyUserById(AdminForm adminForm) {
        if(adminForm.getRole() != null && AdminStatusEnum.getAdminStatusEnum(adminForm.getRole())==null){
            return ResultVO.error(ResultExceptionEnum.DATA_NON_EXISTS.getCode(), "状态值不合法");
        }
        Admin admin = new Admin();
        BeanUtils.copyProperties(adminForm,admin);
        admin.setUpdate_time(new Date());
        int row = adminMapper.modifyUser(admin);

        return row > 0 ? ResultVO.success() : ResultVO.error(-2, "用户修改失败");
    }

    @Override
    public ResultVO getUserInfo(Integer id) {
        Admin admin = adminMapper.getUser(id);
        if(admin==null){
            return ResultVO.error(-2, "管理员不存在");
        }
        return ResultVO.success(admin);
    }

    @Override
    public ResultVO login(String email,String pwd) {
        Admin admin = new Admin();
        Integer id;
        id = adminMapper.getUserid(email);
        admin = adminMapper.getUser(id);
        if (admin.getPassword().equals(pwd))
            return ResultVO.success();
        else
            return ResultVO.error(-2,"登录失败");
    }

    @Override
    public ResultVO regist(String email, String pwd) {
        Admin admin = new Admin();
        admin.setUsername("defaultuser");
        admin.setPassword(pwd);
        admin.setEmail(email);
        admin.setRole(1);
        Date date = new Date();
        admin.setCreate_time(date);
        admin.setUpdate_time(date);
        int row = adminMapper.addUser(admin);

        return row > 0 ? ResultVO.success() : ResultVO.error(-2, "添加用户失败");
    }

    @Override
    public ResultVO modifyPwd(String email, String pwd) {
        Admin admin = new Admin();
        Integer id;
        id = adminMapper.getUserid(email);
        admin = adminMapper.getUser(id);
        if(!admin.getPassword().equals(pwd)&&admin.getPassword()!=null) {
            admin.setPassword(pwd);
            Date date = new Date();
            admin.setUpdate_time(date);
            int row = adminMapper.modifyUser(admin);

            return row > 0 ? ResultVO.success() : ResultVO.error(-2, "密码修改失败");
        }
        else
            return ResultVO.error(-2,"密码不能与原来相同");
    }

    @Override
    public ResultVO modifyUserUsername(Integer id, String username) {
        Admin admin = new Admin();
        admin = adminMapper.getUser(id);
        admin.setUsername(username);
        Date date = new Date();
        admin.setUpdate_time(date);
        int row = adminMapper.modifyUser(admin);

        return row > 0 ? ResultVO.success() : ResultVO.error(-2, "用户名修改失败");
    }

    @Override
    public ResultVO modifyUserPhone(Integer id, String phone) {
        Admin admin = new Admin();
        admin = adminMapper.getUser(id);
        admin.setPhone(phone);
        Date date = new Date();
        admin.setUpdate_time(date);

        int row = adminMapper.modifyUser(admin);

        return row > 0 ? ResultVO.success() : ResultVO.error(-2, "用户电话修改失败");
    }



}
