package com.neutech.service.impl;

import com.neutech.entity.Order;
import com.neutech.entity.Orderitem;
import com.neutech.entity.payInfo;
import com.neutech.entity.shipping;
import com.neutech.mapper.*;
import com.neutech.service.OrderService;
import com.neutech.vo.OrderVO;
import com.neutech.vo.ResultVO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {
    @Autowired
    private OrderitemMapper orderitemMapper;
    @Autowired
    private OrderMapper orderMapper;
    @Autowired
    private payInfoMapper payInfoMapper;
    @Autowired
    private shippingMapper shippingMapper;

    public ResultVO getOrder(Integer id){
        Order order = orderMapper.getOrderById(id);
        List<Orderitem> orderitemList = orderitemMapper.getOrderitemByUserId(order.getUser_id(),order.getOrder_no());
        payInfo payInfo = payInfoMapper.getPayInfoByUserId(order.getUser_id(),order.getOrder_no());
        shipping shipping = shippingMapper.getShippingByUserId(order.getUser_id());
        OrderVO orderVO = new OrderVO();
        BeanUtils.copyProperties(order,orderVO);
        orderVO.setShippingData(shipping);
        orderVO.setPayDetail(payInfo);
        orderVO.setGoods(orderitemList);
        return ResultVO.success(orderVO);
    }

    @Override
    public ResultVO loadOrders(Integer userid, String type) {
        List<Order> orders = new ArrayList<>();
        List<OrderVO> orderVOList = new ArrayList<>();
        if(type.equals("unpay")){
            orders = orderMapper.getOrderByType(1);
        }
        else if(type.equals("unsend")){
            orders = orderMapper.getOrderByType(2);
        }
        else if(type.equals("doing")){
            orders = orderMapper.getOrderByType(3);
        }
        else{
            orders = orderMapper.getAllOrder();
        }
        for(Order order : orders){
            List<Orderitem> orderitemList = orderitemMapper.getOrderitemByUserId(order.getUser_id(),order.getOrder_no());
            payInfo payInfo = payInfoMapper.getPayInfoByUserId(order.getUser_id(),order.getOrder_no());
            shipping shipping = shippingMapper.getShippingByUserId(order.getUser_id());
            OrderVO orderVO = new OrderVO();
            BeanUtils.copyProperties(order,orderVO);
            orderVO.setShippingData(shipping);
            orderVO.setPayDetail(payInfo);
            orderVO.setGoods(orderitemList);
            orderVOList.add(orderVO);
        }
        return ResultVO.success(orderVOList);
    }


}
