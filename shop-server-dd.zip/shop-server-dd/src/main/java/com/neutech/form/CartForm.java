package com.neutech.form;

import javax.validation.constraints.NotNull;
import java.util.Date;

public class CartForm {
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @NotNull(message = "类别id不能为空")
    private Integer id;


    @NotNull(message = "用户id不能为空")
    private Integer userId;
    @NotNull(message = "产品id不能为空")
    private Integer productId;
    @NotNull(message = "数量不能为空")
    private Integer quantity;
    @NotNull(message = "是否选中不能为空")
    private Integer checked;

    public CartForm(Integer id, Integer userId, Integer productId, Integer quantity, Integer checked) {
        this.id = id;
        this.userId = userId;
        this.productId = productId;
        this.quantity = quantity;
        this.checked = checked;
    }


    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Integer getChecked() {
        return checked;
    }

    public void setChecked(Integer checked) {
        this.checked = checked;
    }

    @Override
    public String toString() {
        return "CartForm{" +
                "id=" + id +
                ", userId=" + userId +
                ", productId=" + productId +
                ", quantity=" + quantity +
                ", checked=" + checked +
                '}';
    }

}
