package com.neutech.enumeration;

import com.fasterxml.jackson.annotation.JsonFormat;

@JsonFormat(shape = JsonFormat.Shape.OBJECT)
public enum AdminStatusEnum {
    IS_ADMIN(0, "管理员"),
    NOT_ADMIN(1, "普通用户");

    private Integer statusCode;
    private String statusMsg;

    AdminStatusEnum(Integer statusCode, String statusMsg) {
        this.statusCode = statusCode;
        this.statusMsg = statusMsg;
    }

    public Integer getStatusCode() {
        return statusCode;
    }

    public String getStatusMsg() {
        return statusMsg;
    }

    public static AdminStatusEnum getAdminStatusEnum(Integer code) {
        for (AdminStatusEnum value : values()) {
            if (value.getStatusCode().equals(code)) {
                return value;
            }
        }
        return null;
    }
}
