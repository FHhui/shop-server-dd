package com.neutech.vo;

import com.neutech.entity.Product;
import com.neutech.enumeration.ProductStatusEnum;

import java.math.BigDecimal;
import java.util.Date;

public class ProductVO {

    private Integer id;
    private Integer category_id;
    private String name;
    private String subtitle;
    private String main_image;
    private String[] sub_images;
    private String[] detail;
    private BigDecimal price;
    private Integer stock;
    private ProductStatusEnum status;
    private Date create_time;
    private Date update_time;

    public ProductVO() {
    }

    public ProductVO(Product product){
        this.name=product.getName();
        this.id=product.getId();
        //this.detail=product.getDetail();
        this.detail=product.getDetail().split(",");
        this.category_id =product.getCategoryId();
        this.price=product.getPrice();
        this.subtitle=product.getSubtitle();
        this.main_image =product.getMainImage();
        //private String[] subImages;
        this.stock=product.getStock();
        this.status=ProductStatusEnum.getProductStatusEnum(product.getStatus());
        this.create_time =product.getCreateTime();
        this.update_time =product.getUpdateTime();
        String[] subImages=product.getSubImages().split(",");
        this.sub_images =subImages;
    }
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCategory_id() {
        return category_id;
    }

    public void setCategory_id(Integer category_id) {
        this.category_id = category_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
    }

    public String getMain_image() {
        return main_image;
    }

    public void setMain_image(String main_image) {
        this.main_image = main_image;
    }

    public String[] getSub_images() {
        return sub_images;
    }

    public void setSub_images(String[] sub_images) {
        this.sub_images = sub_images;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Integer getStock() {
        return stock;
    }

    public void setStock(Integer stock) {
        this.stock = stock;
    }

    public ProductStatusEnum getStatus() {
        return status;
    }

    public void setStatus(ProductStatusEnum status) {
        this.status = status;
    }
    public String[] getDetail() {
        return detail;
    }

    public void setDetail(String[] detail) {
        this.detail = detail;
    }

    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }

    public Date getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(Date update_time) {
        this.update_time = update_time;
    }

    @Override
    public String toString() {
        return "ProductVO{" +
                "id=" + id +
                ", categoryId=" + category_id +
                ", name='" + name + '\'' +
                ", subtitle='" + subtitle + '\'' +
                ", mainImage='" + main_image + '\'' +
                ", subImages='" + sub_images + '\'' +
                ", detail=" + detail +
                ", price=" + price +
                ", stock=" + stock +
                ", status=" + status +
                '}';
    }
}
