package com.neutech.vo;

import com.neutech.entity.Orderitem;
import com.neutech.entity.payInfo;
import com.neutech.entity.shipping;

import java.util.Date;
import java.util.List;

public class OrderVO {
    private Integer id;
    private Integer order_no;
    private Integer user_id;
    private shipping shippingData;
    private double payment;
    private payInfo payDetail;
    private Integer postage;
    private Integer status;
    private Date create_time;
    private Date payment_time;
    private Date send_time;
    private Date end_time;
    private Date close_time;
    private Date update_time;
    private List<Orderitem> goods;

    public OrderVO() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getOrder_no() {
        return order_no;
    }

    public void setOrder_no(Integer order_no) {
        this.order_no = order_no;
    }

    public Integer getUser_id() {
        return user_id;
    }

    public void setUser_id(Integer user_id) {
        this.user_id = user_id;
    }

    public shipping getShippingData() {
        return shippingData;
    }

    public void setShippingData(shipping shippingData) {
        this.shippingData = shippingData;
    }

    public double getPayment() {
        return payment;
    }

    public void setPayment(double payment) {
        this.payment = payment;
    }

    public payInfo getPayDetail() {
        return payDetail;
    }

    public void setPayDetail(payInfo payDetail) {
        this.payDetail = payDetail;
    }

    public Integer getPostage() {
        return postage;
    }

    public void setPostage(Integer postage) {
        this.postage = postage;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getCreate_time() {
        return create_time;
    }

    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }

    public Date getPayment_time() {
        return payment_time;
    }

    public void setPayment_time(Date payment_time) {
        this.payment_time = payment_time;
    }

    public Date getSend_time() {
        return send_time;
    }

    public void setSend_time(Date send_time) {
        this.send_time = send_time;
    }

    public Date getEnd_time() {
        return end_time;
    }

    public void setEnd_time(Date end_time) {
        this.end_time = end_time;
    }

    public Date getClose_time() {
        return close_time;
    }

    public void setClose_time(Date close_time) {
        this.close_time = close_time;
    }

    public Date getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(Date update_time) {
        this.update_time = update_time;
    }

    public List<Orderitem> getGoods() {
        return goods;
    }

    public void setGoods(List<Orderitem> goods) {
        this.goods = goods;
    }

    public String toString(){
        return "OrderVO{" +
                "id=" + id +
                ", order_no=" + order_no+
                ", user_id=" + user_id+
                ", shippingData=" + shippingData+
                ", payment=" + payment+
                ", payDetail=" + payDetail+
                ", postage=" + postage+
                ", status=" + status +
                ", create_time=" + create_time+
                ", payment_time=" + payment_time+
                ", send_time=" + send_time+
                ", end_time=" + end_time+
                ", close_time=" + close_time+
                ", update_time=" + update_time +
                ", goods=" + goods +
                '}';
    }
}
