package com.neutech.vo;

import com.fasterxml.jackson.annotation.JsonInclude;

public class ResultVO {

    private Integer code;
    private String msg;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Object data;

    private static final Integer DEFAULT_SUCCESS_CODE = 1;
    private static final String DEFAULT_SUCCESS_MSG = "成功";
    private static final ResultVO DEFAULT_SUCCESS = new ResultVO(DEFAULT_SUCCESS_CODE, DEFAULT_SUCCESS_MSG);

    public static ResultVO success() {
        return DEFAULT_SUCCESS;
    }

    public static ResultVO success(Object data) {
        ResultVO resultVO = new ResultVO();
        resultVO.code = DEFAULT_SUCCESS_CODE;
        resultVO.msg = DEFAULT_SUCCESS_MSG;
        resultVO.data = data;
        return resultVO;
    }

    public static ResultVO error(Integer code, String msg) {
        ResultVO resultVO = new ResultVO();
        resultVO.code = code;
        resultVO.msg = msg;
        return resultVO;
    }

    public ResultVO() {
    }

    public ResultVO(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

    public Object getData() {
        return data;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public void setData(Object data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "ResultVO{" +
                "code=" + code +
                ", msg='" + msg + '\'' +
                ", data=" + data +
                '}';
    }
}
