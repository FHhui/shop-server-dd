package com.neutech.vo;

import java.util.ArrayList;
import java.util.List;

public class WangEditorVO {

    private Integer errno;

    private List<WangEditorItemVO> data;

    public static WangEditorVO success(List<WangEditorItemVO> data) {
        WangEditorVO wangEditorVO = new WangEditorVO();
        wangEditorVO.errno = 0;
        wangEditorVO.data = data;
        return wangEditorVO;
    }

    public static WangEditorVO error() {
        WangEditorVO wangEditorVO = new WangEditorVO();
        wangEditorVO.errno = 1;
        return wangEditorVO;
    }

    public WangEditorVO() {
    }

    public Integer getErrno() {
        return errno;
    }

    public void setErrno(Integer errno) {
        this.errno = errno;
    }

    public List<WangEditorItemVO> getData() {
        return data;
    }

    public void setData(List<WangEditorItemVO> data) {
        this.data = data;
    }
}
