package com.neutech.vo;

import com.neutech.entity.Admin;
import com.neutech.enumeration.AdminStatusEnum;
import java.util.Date;
import java.util.List;

public class AdminVO {
    private Integer userid;
    private String username;
    private String password;
    private String email;
    private String phone;
    private Integer role;
    private Date create_time;
    private Date update_time;

    public AdminVO(){
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public Integer getRole() {
        return role;
    }

    public void setRole(Integer role) {
        this.role = role;
    }

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    public Date getCreate_time() {
        return create_time;
    }

    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }

    public Date getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(Date update_time) {
        this.update_time = update_time;
    }

    @Override
    public String toString() {
        return "Admin{" +
                "userid=" + userid +
                ", username=" + username +
                ", password=" + password +
                ", email=" + email +
                ", phone=" + phone +
                ", role=" + role +
                ", create_time=" + create_time +
                ", update_time=" + update_time +
                '}';
    }
}
