package com.neutech.vo;

import com.neutech.entity.Cart;
import com.neutech.entity.Product;

public class CartVO {
    public CartVO() {
    }

    private Integer id;
    private Integer userId;
    private ProductVO product;
    private Integer quantity;
    private Integer checked;
    public CartVO(Cart cart,ProductVO product) {
        this.id=cart.getId();
        this.userId=cart.getUserId();
        this.product=product;
        this.quantity=cart.getQuantity();
        this.checked=cart.getChecked();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public ProductVO getProduct() {
        return product;
    }

    public void setProduct(ProductVO product) {
        this.product = product;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Integer getChecked() {
        return checked;
    }

    public void setChecked(Integer checked) {
        this.checked = checked;
    }

    public String toString() {
        return "CartVO{" +
                "id=" + id +
                ", userId=" + userId +
                ", productVO='" + product.toString() + '\'' +
                ", quantity='" + quantity + '\'' +
                ", checked='" + checked +
                '}';
    }

}
