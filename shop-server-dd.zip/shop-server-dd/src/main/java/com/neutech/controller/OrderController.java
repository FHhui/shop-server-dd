package com.neutech.controller;

import com.alibaba.fastjson.JSONObject;
import com.neutech.service.OrderService;
import com.neutech.vo.ResultVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping("/getOrder")
    public ResultVO getOrder(@RequestBody JSONObject msg){
        Integer orderid = msg.getInteger("orderid");
        return orderService.getOrder(orderid);
    }

    @PostMapping("/loadOrders")
    public ResultVO loadOrders(@RequestBody JSONObject msg){
        Integer userid = msg.getInteger("userid");
        String type = msg.getString("type");
        return orderService.loadOrders(userid,type);
    }
}
