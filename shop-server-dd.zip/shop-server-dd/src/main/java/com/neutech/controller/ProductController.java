package com.neutech.controller;

import com.alibaba.fastjson.JSONObject;
import com.neutech.entity.Category;
import com.neutech.enumeration.ResultExceptionEnum;
import com.neutech.form.ProductForm;
import com.neutech.service.ProductService;
import com.neutech.vo.ResultVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class ProductController {

    @Autowired
    private ProductService productService;

    @PostMapping("/engineCarousel")
    public ResultVO engineCarousel(){

        return productService.engineCarousel();
    }

    @PostMapping("/GetAllGoods")
    public ResultVO listProduct(@SessionAttribute @RequestParam(defaultValue = "1") Integer pageNum,
                                @RequestBody JSONObject msg) {
        Integer items=msg.getInteger("items");
        return productService.listProduct(pageNum, items);
    }

    /**
     * @description:加载推荐商品
     * */
    @PostMapping("/engineRecommend")
    public ResultVO getProductByCategory(@RequestBody JSONObject msg) {
        Integer categoryId=msg.getIntValue("category_id");
        System.out.println(categoryId);
        return productService.getProductByCategory(categoryId);
    }
    /**
     * @description:搜索商品
     * name:商品名称
     * type:排序标识
     * */
    @PostMapping("/searchProduct")
    public ResultVO getProductByName(@RequestBody JSONObject msg) {
        String name=msg.getString("name");
        Integer type=msg.getInteger("type");
        System.out.println(name);
        System.out.println(type);
        return productService.getProductByName(name,type);
    }

    @GetMapping("/getProductById")
    public ResultVO getProductById(Integer id) {
        return productService.getProductById(id);
    }

    @PostMapping("/addNewGood")
    public ResultVO addProduct(@RequestBody ProductForm productForm) {
        System.out.println(productForm.getCategory_id());
        return productService.addProduct(productForm);
    }

    @PostMapping("/updateProduct")
    public ResultVO updateProduct(@RequestBody ProductForm productForm) {
        if (productForm.getId() == null) {
            return ResultVO.error(ResultExceptionEnum.FORMAT_EXCEPTION.getCode(), "id不能为空");
        }

        return productService.updateProduct(productForm);
    }

    @PostMapping("/RemoveGoodById")
    public ResultVO deleteProduct(@RequestBody JSONObject productForm) {
        Integer id=productForm.getInteger("id") ;
        return productService.deleteProduct(id);
    }

    @PostMapping("/modifyGood")
    public ResultVO modifyGood(@RequestBody ProductForm productForm){
        return productService.updateProduct(productForm);

    }

}
