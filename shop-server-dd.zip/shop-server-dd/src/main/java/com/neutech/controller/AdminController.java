package com.neutech.controller;


import com.alibaba.fastjson.JSONObject;
import com.neutech.enumeration.ResultExceptionEnum;
import com.neutech.form.AdminForm;
import com.neutech.service.AdminService;
import com.neutech.vo.ResultVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class AdminController {

    @Autowired
    private AdminService adminService;

    @PostMapping("/GetAllUsers")
    public ResultVO GetAllUsers() {
        return adminService.GetAllUsers();
    }
    @PostMapping("/getUserInfo")
    public ResultVO getUserInfo(@RequestBody JSONObject msg) {
        Integer userid = msg.getInteger("userid");
        return adminService.getUserInfo(userid);
    }
    @PostMapping("/addNewUser")
    public ResultVO addNewUser(@RequestBody @Valid AdminForm adminForm, BindingResult bindingResult){
        if (bindingResult.getErrorCount() > 0) {
            return ResultVO.error(ResultExceptionEnum.FORMAT_EXCEPTION.getCode(), bindingResult.getAllErrors().get(0).getDefaultMessage());
        }
        return adminService.addNewUser(adminForm);
    }
    @PostMapping("/RemoveUserById")
    public ResultVO RemoveUserById(@RequestBody JSONObject msg){
        Integer userid = msg.getInteger("userid");
        return adminService.RemoveUserById(userid);
    }
    @PostMapping("/modifyUserById")
    public ResultVO modifyUserById(@RequestBody AdminForm adminForm){
        if(adminForm.getId()==null){
            return ResultVO.error(ResultExceptionEnum.FORMAT_EXCEPTION.getCode(), "id不能为空");
        }
        return adminService.modifyUserById(adminForm);
    }
    @PostMapping("/login")
    public ResultVO login(@RequestBody JSONObject msg){
        String email = msg.getString("email");
        String pwd = msg.getString("pwd");
        return adminService.login(email,pwd);
    }
    @PostMapping("/regist")
    public ResultVO regist(@RequestBody JSONObject msg){
        String email = msg.getString("email");
        String pwd = msg.getString("pwd");
        return adminService.regist(email,pwd);
    }
    @PostMapping("/modifyPwd")
    public ResultVO modifyPwd(@RequestBody JSONObject msg){
        String email = msg.getString("email");
        String pwd = msg.getString("pwd");
        return adminService.modifyPwd(email,pwd);
    }
    @PostMapping("/modifyUserUsername")
    public ResultVO modifyUserUsername(@RequestBody JSONObject msg){
        Integer userid = msg.getInteger("userid");
        String username = msg.getString("username");
        return adminService.modifyUserUsername(userid,username);
    }
    @PostMapping("/modifyUserPhone")
    public ResultVO modifyUserPhone(@RequestBody JSONObject msg){
        Integer userid = msg.getInteger("userid");
        String phone = msg.getString("phone");
        return adminService.modifyUserPhone(userid,phone);
    }

}
