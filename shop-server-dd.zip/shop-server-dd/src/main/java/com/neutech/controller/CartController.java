package com.neutech.controller;

import com.alibaba.fastjson.JSONObject;
import com.neutech.entity.Cart;
import com.neutech.form.CartForm;
import com.neutech.form.ProductForm;
import com.neutech.service.CartService;
import com.neutech.vo.ResultVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.web.bind.annotation.*;
import org.springframework.stereotype.Service;
import sun.security.util.math.intpoly.IntegerPolynomialP384;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class CartController {
    @Autowired
    private CartService cartService;

    @PostMapping("/getCart")
    public ResultVO getCart(@RequestBody JSONObject msg) {

        Integer userID = msg.getInteger("userid");
        return cartService.listCarts(userID);
    }

    @PostMapping("/addProductToCarts")
    public ResultVO addProductToCarts(CartForm cartForm) {
        return cartService.addProductToCarts(cartForm);
    }

    @PostMapping("/removeGoodFromCart")
    public ResultVO DeleteCarts(@RequestBody JSONObject msg) {
        Integer userId = msg.getInteger("userid");
        Integer goodId = msg.getInteger("id");
        return cartService.DeleteCarts(userId, goodId);
    }

    @PostMapping("/upDateCarts")
    public ResultVO upDateCarts(CartForm cartForm) {
        return cartService.upDateCarts(cartForm);
    }

    @PostMapping("/changeCheck")
    public ResultVO changeCheck(@RequestBody JSONObject msg) {
        Integer userID = msg.getInteger("userid");
        Integer id = msg.getInteger("id");
        Integer check = msg.getIntValue("check");
        System.out.println(check);
        return cartService.changeCheck(userID, id, check);
    }

    @PostMapping("/changeCount")
    public ResultVO changeCount(@RequestBody JSONObject msg) {
        Integer userID = msg.getInteger("userid");
        Integer id = msg.getInteger("id");
        Integer quantity = msg.getInteger("count");
        return cartService.changeCount(userID, id, quantity);
    }

    @GetMapping("/EvaluateCarts")
    public ResultVO EvaluateCarts(Integer userId) {

        return cartService.EvaluateCarts(userId);
    }
}
