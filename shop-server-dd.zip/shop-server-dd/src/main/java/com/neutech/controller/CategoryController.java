package com.neutech.controller;

import com.neutech.service.CategoryService;
import com.neutech.vo.ResultVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/category")
@CrossOrigin
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    @GetMapping("/listTopCategoryStruct")
    public ResultVO listTopCategoryStruct() {
        return categoryService.listTopStruct();
    }

    @PostMapping("/addCategory")
    public ResultVO addCategory() {
        return ResultVO.success();
    }

}
