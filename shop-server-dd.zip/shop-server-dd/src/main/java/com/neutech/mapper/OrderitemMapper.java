package com.neutech.mapper;

import com.neutech.entity.Orderitem;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface OrderitemMapper {
    List<Orderitem> getOrderitemByUserId(@Param("userId") Integer userId, @Param("orderNo") Integer orderNo);
}
