package com.neutech.mapper;

import com.neutech.entity.Category;

import java.util.List;

public interface CategoryMapper {

    Category getOneById(Integer id);

    List<Category> listByParentId(Integer parentId);

    List<Category> listTopStruct();

}
