package com.neutech.mapper;

import com.neutech.entity.shipping;

public interface shippingMapper {
    shipping getShippingByUserId(Integer userId);
}
