package com.neutech.mapper;

import com.neutech.entity.Cart;
import com.neutech.entity.Product;

import java.util.List;

public interface CartMapper {
    List<Cart> listCart(Integer userId);
    Cart getOneByID(Integer cartId);
    int update(Cart cart);
    int deleteById(Integer userId,Integer goodId);
    int add(Cart cart);
    int changeCheck(Integer userId,Integer id,Integer check);
    int changeCount(Integer userId,Integer id,Integer quantity);

}
