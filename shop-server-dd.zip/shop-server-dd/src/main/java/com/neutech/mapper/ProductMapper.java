package com.neutech.mapper;

import com.neutech.entity.Product;

import java.util.List;

public interface ProductMapper {

    List<Product> listProduct();

    List<Product> getProductByCategory(Integer categoryId);

    List<Product> getProductByName(String name,Integer type);

    Product getOneById(Integer id);

    int save(Product product);

    int update(Product product);

    int deleteAllByIds(Integer ids);


}
