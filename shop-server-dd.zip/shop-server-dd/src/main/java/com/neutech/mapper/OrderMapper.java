package com.neutech.mapper;

import com.neutech.entity.Order;

import java.util.List;

public interface OrderMapper {
    Order getOrderById(Integer id);
    List<Order> getOrderByType(Integer status);
    List<Order> getAllOrder();
}
