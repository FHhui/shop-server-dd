package com.neutech.mapper;

import com.neutech.entity.Admin;

import java.util.List;

public interface AdminMapper {
    List<Admin> GetAllUser();
    Admin getUser(Integer id);
    int getUserid(String email);
    int RemoveUser(Integer id);
    int addUser(Admin admin);
    int modifyUser(Admin admin);
}
