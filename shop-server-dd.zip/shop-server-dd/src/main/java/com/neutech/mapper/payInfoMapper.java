package com.neutech.mapper;

import com.neutech.entity.payInfo;
import org.apache.ibatis.annotations.Param;

public interface payInfoMapper {
    payInfo getPayInfoByUserId(@Param("userId") Integer userId, @Param("orderNo") Integer orderNo);
}
